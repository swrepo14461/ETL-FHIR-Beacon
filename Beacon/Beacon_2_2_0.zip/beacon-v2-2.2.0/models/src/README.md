This directory contains the schema files for the Beacon model(s).

The schemas are edited in this [`../src`](../src) directory and exported into a [`json` representation](../json).

The JSON versions of the files serves as the default / referenceable version of the schemas.
