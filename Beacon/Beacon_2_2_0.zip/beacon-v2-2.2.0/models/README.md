This directory contains the schema files for the Beacon model(s).

The schemas are edited in the [`../src`](../src) directory and exported into [`../json`](../json) representation.

The JSON versions of the files serves as the default / referenceable version of the schemas.

**The schema files in this directory should not be edited directly.**
