This directory contains the schema files for the Beacon framework.

The schemas are edited in [`../src`](../src) and generated into [`../json`](../json) and [`.yaml`](../representations).

The JSON versions of the files serves as the default / referenceable version of the
schemas.