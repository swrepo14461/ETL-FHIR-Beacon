This directory contains the schema source files for the Beacon framework.

The schemas are edited in [`../src`](../src) and generated into [`../json`](../json) representations.

The JSON versions of the files serves as the default / referenceable version of the
schemas.
