This directory contains the Beacon documentation. The files here are rendered through
MkDocs and available at [genomebeacons.org/beacon-v2/](https://genomebeacons.org/beacon-v2/).